import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Phone, Mail, MapPin, ArrowRight, Star, Navigation } from "lucide-react";
import { BUSINESS, MSG, createWhatsAppLink, WHATSAPP_NUMBER, CLEANING, PEST, pestMessage, FLORA, floraMessage, REVIEWS, MAP_EMBED, MAP_DIRECTIONS } from "@/lib/site";
import { IMG, VIDEOS } from "@/lib/media";
import { WhatsAppIcon } from "@/components/site/Chrome";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cleaning, Pest Control & Floriculture in Alimosho, Lagos | Excellent Amazing" },
      { name: "description", content: "Residential, office and move-in cleaning, sofa, rug and mattress cleaning, formigation / pest control and floriculture in Ipaja, Alimosho, Lagos. Book on WhatsApp." },
      { property: "og:title", content: "Excellent Amazing Cleaning and Pest Control Services" },
      { property: "og:description", content: "Cleaning, formigation / pest control and floriculture services in Alimosho, Lagos. Book easily on WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const wa = (m: string) => ({ href: createWhatsAppLink(m), target: "_blank", rel: "noopener noreferrer" });

function SectionHead({ eyebrow, title, intro, light }: { eyebrow: string; title: string; intro?: string; light?: boolean }) {
  return (
    <div className="max-w-2xl reveal">
      <p className={`eyebrow ${light ? "text-accent" : ""}`}>{eyebrow}</p>
      <h2 className="mt-3 text-3xl font-medium leading-tight sm:text-4xl lg:text-[2.75rem]">{title}</h2>
      {intro && <p className={`mt-4 text-base leading-relaxed ${light ? "text-ink-foreground/75" : "text-muted-foreground"}`}>{intro}</p>}
    </div>
  );
}

function Index() {
  return (
    <>
      <Hero />
      <About />
      <Services />
      <Cleaning />
      <Pest />
      <Flora />
      <WhyUs />
      <Work />
      <HowItWorks />
      <Reviews />
      <Contact />
      <FindUs />
      <FinalCta />
    </>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 py-14 lg:grid-cols-12 lg:gap-14 lg:px-8 lg:py-24">
        <div className="lg:col-span-6">
          <p className="eyebrow text-accent">Ipaja · Alimosho · Lagos</p>
          <h1 className="mt-5 text-4xl font-medium leading-[1.05] sm:text-5xl lg:text-6xl">
            Cleaner homes. <em className="text-accent">Pest-free</em> spaces. Living gardens.
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-foreground/75">
            Professional cleaning, formigation / pest control and floriculture services for homes and businesses. Choose your service and book in minutes through WhatsApp.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Link to="/book-service" className="btn btn-accent">Book a Service <ArrowRight className="h-4 w-4" /></Link>
            <a {...wa(MSG.chat)} className="btn btn-whatsapp"><WhatsAppIcon />Chat on WhatsApp</a>
          </div>
          <ul className="mt-10 flex flex-wrap gap-x-6 gap-y-2 text-sm text-ink-foreground/70">
            <li>Cleaning Service</li><li aria-hidden>·</li><li>Formigation / Pest Control</li><li aria-hidden>·</li><li>Floriculture</li>
          </ul>
        </div>
        <div className="relative lg:col-span-6">
          <img src={IMG.team} alt="The Excellent Amazing team with their cleaning equipment" width={1080} height={811} className="aspect-[4/3] w-full rounded-lg object-cover" />
          <img src={IMG.sofa1} alt="Team member vacuuming a sofa" loading="lazy" className="absolute -bottom-8 -left-4 hidden aspect-[3/4] w-40 rounded-lg border-4 border-ink object-cover sm:block lg:-left-10 lg:w-48" />
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
      <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-5">
          <SectionHead eyebrow="About us" title="A professional team that takes care of your space, inside and out." />
        </div>
        <div className="space-y-5 text-lg leading-relaxed text-muted-foreground lg:col-span-7 reveal">
          <p>
            <strong className="font-semibold text-foreground">{BUSINESS.name}</strong> is based in Ipaja, Alimosho, Lagos. We clean homes and offices, treat properties for pests, and help clients create and maintain healthy gardens.
          </p>
          <p>
            Our team works carefully, explains what we are doing, and keeps communication simple. Every booking and enquiry goes straight to us on WhatsApp, so you can talk to a real person about exactly what you need.
          </p>
        </div>
      </div>
    </section>
  );
}

const SERVICE_CARDS = [
  { title: "Cleaning Service", img: IMG.sofa3, desc: "Residential, office and move-in / move-out cleaning, plus sofa, rug and mattress cleaning.", href: "#cleaning" },
  { title: "Formigation / Pest Control Service", img: IMG.bedbugs, desc: "Treatment for cockroaches, ants, mosquitoes, bedbugs, termites, rodents and general pests.", href: "#pest" },
  { title: "Floriculture Service", img: IMG.flowerBed, desc: "Landscaping, flower planting, garden creation and maintenance, plus gardening supplies.", href: "#floriculture" },
];

function Services() {
  return (
    <section id="services" className="border-y bg-card">
      <div className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
        <SectionHead eyebrow="Our services" title="Three services, one trusted team." />
        <div className="mt-14 grid gap-px overflow-hidden rounded-lg border bg-border md:grid-cols-3">
          {SERVICE_CARDS.map((s, i) => (
            <a key={s.title} href={s.href} className="group flex flex-col bg-card reveal">
              <div className="aspect-[4/3] overflow-hidden">
                <img src={s.img} alt={s.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              </div>
              <div className="flex flex-1 flex-col p-7">
                <span className="font-display text-sm text-muted-foreground">0{i + 1}</span>
                <h3 className="mt-2 text-2xl font-medium">{s.title}</h3>
                <p className="mt-3 flex-1 text-muted-foreground">{s.desc}</p>
                <span className="mt-6 inline-flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-primary">
                  View categories <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function Cleaning() {
  return (
    <section id="cleaning" className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
      <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
        <div className="grid grid-cols-2 gap-3 reveal">
          <img src={IMG.rug2} alt="Rug being scrubbed by our team" loading="lazy" className="row-span-2 h-full w-full rounded-lg object-cover" />
          <img src={IMG.mattress1} alt="Mattress cleaning in progress" loading="lazy" className="aspect-square w-full rounded-lg object-cover" />
          <img src={IMG.bathroom} alt="Bathroom cleaning" loading="lazy" className="aspect-square w-full rounded-lg object-cover" />
        </div>
        <div>
          <SectionHead eyebrow="Cleaning service" title="Careful, detailed cleaning for every room." intro="Choose from six cleaning categories. Sofa, rug and mattress cleaning come in Basic or Premium options." />
          <ol className="mt-10 divide-y border-y">
            {CLEANING.map((c, i) => (
              <li key={c.id} className="flex items-start gap-5 py-5">
                <span className="font-display text-sm text-muted-foreground">0{i + 1}</span>
                <div className="flex-1">
                  <h3 className="font-sans text-base font-semibold">{c.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{c.desc}</p>
                </div>
              </li>
            ))}
          </ol>
          <Link to="/book-service" search={{ service: "cleaning" }} className="btn btn-primary mt-8">Book Cleaning <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </div>
    </section>
  );
}

function Pest() {
  return (
    <section id="pest" className="bg-ink text-ink-foreground">
      <div className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
        <div className="grid items-end gap-10 lg:grid-cols-2">
          <SectionHead light eyebrow="Formigation / Pest Control" title="Targeted treatment for the pests you're dealing with." intro="Select the pest below and WhatsApp opens with your enquiry ready. We'll share the available options and price." />
          <img src={IMG.bedbugs} alt="Close-up of bedbugs" loading="lazy" className="aspect-[16/9] w-full rounded-lg object-cover lg:aspect-[16/8]" />
        </div>
        <div className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PEST.map((p) => (
            <a key={p} {...wa(pestMessage(p))} className="group flex items-center justify-between gap-4 rounded-md border border-ink-foreground/15 px-6 py-5 transition-colors hover:border-accent hover:bg-ink-foreground/5">
              <span className="font-display text-xl">{p}</span>
              <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-accent">
                <WhatsAppIcon className="h-4 w-4" />Inquire
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function Flora() {
  return (
    <section id="floriculture" className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
      <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-5">
          <SectionHead eyebrow="Floriculture service" title="Gardens and greenery, planted and cared for." intro="From landscaping and garden creation to pots, plants and manure supply. Tap any service to enquire on WhatsApp." />
          <div className="mt-10 grid grid-cols-3 gap-3">
            <img src={IMG.planterTrees} alt="Planted trees in white planters" loading="lazy" className="aspect-[3/4] w-full rounded-lg object-cover" />
            <img src={IMG.palms} alt="Palm seedlings" loading="lazy" className="aspect-[3/4] w-full rounded-lg object-cover" />
            <img src={IMG.pots} alt="Flower pots for supply" loading="lazy" className="aspect-[3/4] w-full rounded-lg object-cover" />
          </div>
        </div>
        <ul className="grid content-start gap-x-8 sm:grid-cols-2 lg:col-span-7">
          {FLORA.map((f) => (
            <li key={f} className="border-b">
              <a {...wa(floraMessage(f))} className="group flex items-center justify-between gap-4 py-5">
                <span className="font-medium">{f}</span>
                <WhatsAppIcon className="h-5 w-5 shrink-0 text-whatsapp transition-transform group-hover:scale-110" />
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

const WHY = [
  { t: "Professional service", d: "Our team arrives prepared with the right equipment and works carefully throughout your property." },
  { t: "Responsive communication", d: "Talk to us directly on WhatsApp. We explain treatments and services clearly." },
  { t: "Cleaning expertise", d: "Homes, offices, move-ins, sofas, rugs and mattresses — handled with attention to detail." },
  { t: "Pest control & floriculture", d: "One team for cleaning, pest treatment and garden care, so you don't need three providers." },
  { t: "Easy WhatsApp booking", d: "Choose your service online and your booking message is prepared for you. No accounts, no payment forms." },
];

function WhyUs() {
  return (
    <section className="border-y bg-secondary">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-12 lg:px-8 lg:py-28">
        <div className="lg:col-span-4">
          <SectionHead eyebrow="Why choose us" title="Why clients call us back." />
        </div>
        <dl className="grid gap-x-10 gap-y-10 sm:grid-cols-2 lg:col-span-8">
          {WHY.map((w) => (
            <div key={w.t} className="border-t border-foreground/20 pt-5 reveal">
              <dt className="font-display text-xl">{w.t}</dt>
              <dd className="mt-2 text-muted-foreground">{w.d}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}

const GALLERY: { src: string; alt: string; cat: string }[] = [
  { src: IMG.sofa1, alt: "Vacuuming a sofa", cat: "Sofa Cleaning" },
  { src: IMG.sofa2, alt: "Cleaning a sectional sofa", cat: "Sofa Cleaning" },
  { src: IMG.sofa3, alt: "Cleaning a grey sofa", cat: "Sofa Cleaning" },
  { src: IMG.rug1, alt: "Vacuuming a patterned rug", cat: "Cleaning" },
  { src: IMG.rug2, alt: "Scrubbing a shaggy rug", cat: "Cleaning" },
  { src: IMG.mattress1, alt: "Mattress cleaning", cat: "Cleaning" },
  { src: IMG.mattress2, alt: "Cleaned mattress", cat: "Cleaning" },
  { src: IMG.headboard, alt: "Headboard cleaning", cat: "Cleaning" },
  { src: IMG.bathroom, alt: "Bathroom cleaning", cat: "Other Cleaning Work" },
  { src: IMG.gateWash, alt: "Pressure washing a gate", cat: "Other Cleaning Work" },
  { src: IMG.lawn, alt: "Lawn planting", cat: "Floriculture" },
  { src: IMG.plantPot, alt: "Potted palm", cat: "Floriculture" },
  { src: IMG.plant, alt: "Young banana plant", cat: "Floriculture" },
  { src: IMG.planters, alt: "Planters for supply", cat: "Floriculture" },
];
const FILTERS = ["All", "Cleaning", "Sofa Cleaning", "Other Cleaning Work", "Floriculture", "Videos"];

function Work() {
  const [f, setF] = useState("All");
  const items = f === "All" ? GALLERY : GALLERY.filter((g) => g.cat === f);
  const showVideos = f === "All" || f === "Videos";
  return (
    <section id="work" className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
      <SectionHead eyebrow="Our work" title="Real work. Real results." intro="Photos and videos from our own jobs." />
      <div className="mt-10 flex gap-2 overflow-x-auto pb-2" role="tablist">
        {FILTERS.map((x) => (
          <button key={x} role="tab" aria-selected={f === x} onClick={() => setF(x)}
            className={`shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-colors ${f === x ? "border-primary bg-primary text-primary-foreground" : "hover:border-primary"}`}>
            {x}
          </button>
        ))}
      </div>
      {showVideos && (
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {VIDEOS.map((v, i) => (
            <video key={v.src} src={v.src} poster={v.poster} controls playsInline preload="none" muted
              className="aspect-[9/16] w-full rounded-lg bg-ink object-cover" aria-label={`Work video ${i + 1}`} />
          ))}
        </div>
      )}
      {f !== "Videos" && (
        <div className="mt-4 columns-2 gap-4 md:columns-3 lg:columns-4">
          {items.map((g) => (
            <figure key={g.src} className="mb-4 break-inside-avoid overflow-hidden rounded-lg">
              <img src={g.src} alt={g.alt} loading="lazy" className="w-full transition-transform duration-700 hover:scale-105" />
            </figure>
          ))}
        </div>
      )}
    </section>
  );
}

const STEPS = [
  ["Visit our website", "Explore our services."],
  ["Choose your service", "Cleaning, Formigation / Pest Control or Floriculture."],
  ["Choose your category", "Select exactly what you need."],
  ["View your price", "Shown only where the business has a confirmed fixed price."],
  ["Enter your details", "Only where the selected service requires customer details."],
  ["Send to WhatsApp", "Your booking or inquiry message is prepared."],
  ["We contact you", "We receive your request and get in touch."],
];

function HowItWorks() {
  return (
    <section id="how" className="border-y bg-card">
      <div className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
        <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
          <SectionHead eyebrow="How it works" title="How our booking works" />
          <Link to="/book-service" className="btn btn-primary self-start">Start booking <ArrowRight className="h-4 w-4" /></Link>
        </div>
        <ol className="mt-14 grid gap-px overflow-hidden rounded-lg border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map(([t, d], i) => (
            <li key={t} className={`bg-card p-7 ${i === 6 ? "bg-primary text-primary-foreground lg:col-span-1" : ""}`}>
              <span className={`font-display text-4xl ${i === 6 ? "text-accent" : "text-primary"}`}>0{i + 1}</span>
              <h3 className="mt-6 font-sans text-sm font-bold uppercase tracking-wider">{t}</h3>
              <p className={`mt-2 text-sm ${i === 6 ? "text-primary-foreground/80" : "text-muted-foreground"}`}>{d}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Reviews() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
      <SectionHead eyebrow="Reviews" title="What our clients say" />
      <div className="mt-14 grid gap-10 lg:grid-cols-3">
        {REVIEWS.map((r, i) => (
          <figure key={r.name} className={`flex flex-col reveal ${i === 0 ? "lg:col-span-1" : ""}`}>
            <div className="flex gap-1 text-accent" aria-label="5 out of 5 stars">
              {Array.from({ length: 5 }).map((_, k) => <Star key={k} className="h-4 w-4 fill-current" />)}
            </div>
            <blockquote className="mt-5 flex-1 font-display text-lg leading-relaxed">"{r.text}"</blockquote>
            <figcaption className="mt-6 border-t pt-4 text-sm font-semibold">{r.name}</figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}

function Contact() {
  const rows = [
    { icon: Phone, label: "Phone", value: BUSINESS.phoneDisplay, href: `tel:${BUSINESS.phoneTel}` },
    { icon: WhatsAppIcon, label: "WhatsApp", value: WHATSAPP_NUMBER, href: createWhatsAppLink(MSG.chat) },
    { icon: Mail, label: "Email", value: BUSINESS.email, href: `mailto:${BUSINESS.email}` },
    { icon: MapPin, label: "Address", value: BUSINESS.address },
  ];
  return (
    <section id="contact" className="border-t bg-secondary">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 sm:py-20 lg:grid-cols-2 lg:gap-12 lg:px-8 lg:py-28">
        <div className="min-w-0">
          <SectionHead eyebrow="Contact" title="Let's talk about your space." />
          <p className="mt-3 text-sm text-muted-foreground">{BUSINESS.name}</p>
          <div className="mt-8 grid grid-cols-2 gap-3">
            <a href={`tel:${BUSINESS.phoneTel}`} className="btn btn-primary px-3 text-xs sm:text-sm"><Phone className="h-4 w-4 shrink-0" />Call Now</a>
            <a href={`mailto:${BUSINESS.email}`} className="btn btn-outline px-3 text-xs text-primary sm:text-sm"><Mail className="h-4 w-4 shrink-0" />Email Us</a>
            <a {...wa(MSG.chat)} className="btn btn-whatsapp col-span-2 px-3"><WhatsAppIcon />Chat on WhatsApp</a>
            <Link to="/book-service" className="btn btn-accent col-span-2 px-3">Book a Service</Link>
          </div>
          <a {...wa(MSG.letsTalk)} className="mt-6 inline-flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-primary hover:underline">
            Let's talk <ArrowRight className="h-4 w-4" />
          </a>
        </div>
        <ul className="min-w-0 divide-y overflow-hidden rounded-lg border bg-card">
          {rows.map(({ icon: Icon, label, value, href }) => (
            <li key={label} className="flex gap-3 p-4 sm:gap-4 sm:p-6">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-secondary text-primary">
                <Icon className="h-4 w-4" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="eyebrow">{label}</p>
                {href ? (
                  <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer" className="mt-1 block text-[0.95rem] font-medium [overflow-wrap:anywhere] hover:text-primary sm:text-lg">{value}</a>
                ) : (
                  <p className="mt-1 text-[0.95rem] font-medium leading-relaxed sm:text-lg">{value}</p>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function FindUs() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-24">
      <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
        <div>
          <SectionHead eyebrow="Find us" title="Visit us or get directions to our location." />
          <p className="mt-4 flex gap-2 text-muted-foreground"><MapPin className="mt-0.5 h-5 w-5 shrink-0 text-primary" />{BUSINESS.address}</p>
        </div>
        <a href={MAP_DIRECTIONS} target="_blank" rel="noopener noreferrer" className="btn btn-primary self-start"><Navigation className="h-4 w-4" />Get Directions</a>
      </div>
      <div className="mt-10 overflow-hidden rounded-lg border">
        <iframe title="Map showing our location in Ipaja, Alimosho, Lagos" src={MAP_EMBED} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="h-[360px] w-full border-0 md:h-[460px]" />
      </div>
    </section>
  );
}

function FinalCta() {
  return (
    <section className="bg-primary text-primary-foreground">
      <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 px-5 py-16 lg:flex-row lg:items-center lg:px-8 lg:py-20">
        <div className="max-w-2xl">
          <h2 className="text-3xl font-medium sm:text-4xl">Ready to book a service?</h2>
          <p className="mt-3 text-primary-foreground/80">Choose the service you need and contact {BUSINESS.name}.</p>
        </div>
        <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
          <Link to="/book-service" className="btn btn-accent">Book a Service</Link>
          <a {...wa(MSG.chat)} className="btn btn-whatsapp"><WhatsAppIcon />Chat on WhatsApp</a>
        </div>
      </div>
    </section>
  );
}
