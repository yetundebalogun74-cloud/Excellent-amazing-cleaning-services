# Deploying on Vercel

1. Extract the ZIP. Put the contents of the `ea` folder in a GitHub repository (include the configuration files, source, and public media).
2. On vercel.com: Add New → Project → import that repository.
3. Set Framework Preset to **Other** and Node.js to **22.x**. Use the repository root as Root Directory (or `ea` if you uploaded that folder itself). The included `vercel.json` sets the build command. Leave Output Directory unset: the Nitro Vercel preset generates `.vercel/output` automatically.
4. Click Deploy.

Run locally: `bun install` then `bun run dev` and open the local URL shown in the terminal.

Edit business details, WhatsApp number, time slots and prices in `src/lib/site.ts`.
Photos and videos live in `public/media/`.
